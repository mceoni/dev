export interface IPedido {
    id: number
    data: string
    entrega: string
    total: number
}